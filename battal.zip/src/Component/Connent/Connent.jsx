import React from 'react'
import "./Connect.css"

function Connent() {
  return (
    <div className='container-fluid mt-3 m-0 p-0'>
      <div className="row  border_css  justify-content-center py-4 m-0">
        <div className="col-lg-12">
        <p>Connect your wallet to stake IBAT tokens!</p>

<button className='btn btn-md lst_btnn mt-3 text-white btn_css'>Connect Wallet</button>
        </div>

      </div>
    </div>
  )
}

export default Connent
